# BASS_HE PR135: SOURCE-OWNED COHERENT π0 PHOTON REINJECTION + ORIGINAL 1958 FASTD

**Parent immutable:** Draft PR #134 HEAD `241d8e90607ff7ff28ca643a8e39ae189bde3d19`. Add-only separate branch, no merge/force push. **2026-10-31.**

## New source physics

EXFOR request 10461 in the verified source-owned PR134 archive gives Rambo et al. 1999 `M0752019` coherent `gamma + 4He -> pi0 + 4He` total source cross-section 17 points, 206..397 MeV (focus 206,216,229,241 MeV), and angular differential `M0752002..M0752005` 101 rows in 201..246 MeV incident energy bins. `M0752001` supplies 7% source-wide systematic and 2 MeV incident energy resolution. `M0384002` supplies separate 2p2n exclusive breakup (8 rows, 155..435 MeV; 155MeV is 0±26.3μb, not exact zero). `M0520002` is MacCormick1997 measured total photoabsorption, NOT a measured pion cross-section; interpolation of inclusive only inside measured adjacent endpoints. Same EXFOR owner already appears in parent PR134 so entries are new *physical uses*, not claimed new experiments.

At Eγ=206,216,229,241 MeV, direct measured coherent σπ0=(150.0±0.8,174.5±0.8,212.6±0.9,260.3±1.0) μb (stat) and 7% common systematic. Source ratios σπ0/σabs interpolated across independent MacCormick measurements are approximately (20.049%,19.852%,20.828%,22.648%). Crucially an independent primary detector acceptance proof that MacCormick includes the fully coherent neutral-only channel was **not** obtained, so these ratios are **conditional source comparison**, not a proven exclusive partition of one experiment. Other nuclear channels and the neutral-pion 1.177%-non-2γ branch are kept separate.

### Derivation: π0 production, decay, exact kinematic envelope

Use signature (-,+,+,+); rest energies μ_α=M_α c² and μ_π=m_π c² in MeV, with explicit c in the definitions. For target 4He stationary in the local FLRW plasma, the initial photon energy is Eγ; exact special-relativistic two-body kinematics:

- s=μ_α²+2 μ_α Eγ, E_thr=μ_π+μ_π²/(2μ_α)=137.42070690 MeV.
- Eπ*= (s+μ_π²−μ_α²)/(2√s), pπ*c=√(Eπ*²−μ_π²).
- β_CM=Eγ/(μ_α+Eγ), γ_CM=(μ_α+Eγ)/√s.
- Eπ^lab(μ)=γ_CM[Eπ*+β_CM pπ*c μ] with μ=cos θπ*.
- α recoil kinetic T_α=Eγ−Eπ^lab (α **survives**).
- Conditional on π0→2γ, 2 photons have laboratory energy density uniform on [ε−,ε+] = [(Eπ−pπ c)/2,(Eπ+pπ c)/2]. Their sum of energies is Eπ, not the original photon Eγ (recoil carries the difference).
- PDG2025 π0 mass=134.9768 MeV/c²; B(2γ)=0.98823±0.00034; mean lifetime 8.43e-17 s. Other decay branches not converted to two photons.

Define q(ε|Eπ)=1/(ε+−ε−) within that interval. At the four pion source Eγ values, angular measured data cover **only** θ_CM ≈ 7°..147° (fourth ends at 142°). The source angular conditional normalized shape w(μ) is proportional to (dσ/dΩ)(μ) on that interval, not a calibrated all-sky differential distribution. Computed *conditional first-generation* pair-photon transfer spectrum:

    K_π(ε | Eγ, observed angular support) = 2 B_2γ ∫_support dμ w(μ) q(ε|Eπ(Eγ,μ)).

The emitted-photon source per incident test γ is Pπ^(first) × Kπ, where

    Pπ^(first)(Eγ,z)= [nα(z) c σπ0^measured(Eγ)] /
       [Γ_BW(Eγ,z)+Γ_BH(Eγ,z)+Γ_KN(Eγ,z)+nα(z)c σabs^EXFOR_interp(Eγ)].

Here σabs is **one inclusive terminal first-hit rate**, not added to a separately counted π0 rate in the denominator; this is a conditional model contract that assumes the inclusive measurement covers the coherent process. Other EM processes omitted; no redshift evolution during the local first hit; no full pair IC cascade and no follow-up below 150 MeV. An angular-independent **rigorous kinematic envelope** is also obtained by letting μ cover [-1,1], avoiding unsupported full-sky angular extrapolation.

For one produced π0, photon daughters with ε>150MeV (expected number including 2γ branching), by Eγ=206,216,229,241MeV: [0.18307,0.38733], [0.29914,0.49303], [0.42276,0.60687], [0.51713,0.69464]. The angle-conditioned measured-support estimates lie inside these bounds. At Eγ=216 MeV,z=1e4, Pπ^(first)=0.00094807506691 and the high-energy daughters per injected test γ range [0.00028360635,0.00046742662], with measured-angular-support proxy ~0.00039987347. All sub-150MeV photons remain **untracked photons**, NOT heat. The 2γ decay is prompt relative to local Hubble (Hτπ≪1).

### Original Gorbunov–Spiridonov (1958) fast-deuteron experiment

*Photodisintegration of Helium. III*, Soviet Physics JETP 7 (1958) 600–605, original PDF p.604 Table II, measured *mean momentum magnitudes* p/c (MeV/c) for γ+4He→p+n+D, by **bremsstrahlung energy BIN**, not a 220MeV monochromatic DD source:

| Photon incident bin | mean p_proton | mean p_neutron | mean p_deuteron | inferred Jensen floor ⟨K_D⟩ |
|---|---:|---:|---:|---:|
| 25.9–75 MeV | 123 | 118 | 124 MeV/c | >= 4.094457622 MeV |
| 75–170 MeV | 214 | 259 | 190 MeV/c | >= 9.598958076 MeV |

Because K(p)=√[(pc)²+(mc²)²]−mc² is convex for |p|≥0, Jensen gives ⟨K(p)⟩≥K(⟨|p|⟩), NOT equality. For selected common p,n,D events, total K floor plus the reaction Q=26.0711MeV further implies ⟨Eγ⟩>=45.57419MeV in lower bin, >=94.80945MeV in upper bin. These are conditional bounds on the selected experimental ensemble and no 150–250MeV fastD pointwise sample is claimed. The three-body D is not the same as a two-body DD daughter.

## Measured input vs derived physical output

- 128 source-owned table rows in scope (17 π0 totals +101 π0 angular +8 2p2n +2 original JETP momentum bins) used or preserved, NOT 128 independent *newly conducted* experiments.
- 826 new CONDITIONAL derived physics rows: 200 normalized support-angle photon spectra + 600 first-hit induced photon spectra + 12 first-hit/projection + 4 exact angular-independent kinematic envelopes +4 measured angular moments +4 source ratio/covariance summaries +2 fastD Jensen bounds. No absolute cosmic source. Five original scientific PNG and five SVG figures.
- Review caveat: angular partial [7°,147°] integrals can exceed source total by ~1%, within 7% reported systematic; do NOT force-fit or count a full-sphere normalized angular distribution. Measurement × model energy-bin alignment, inclusive absorption cross-experiment coverage, and missing pion Dalitz branch constrain claim scope.
- SOURCE=Rambo et al. Nucl. Phys. A 660,69 (1999), DOI:10.1016/S0375-9474(99)00383-8, EXFOR M0752001..2019; MacCormick et al. PRC55,1033(1997), DOI:10.1103/PhysRevC.55.1033, EXFOR M0520002; TAGX Emura et al. PLB286,229(1992), DOI:10.1016/0370-2693(92)91767-4 EXFOR M0384002. Original 1958 JETP PDF in prior private archive. PDG π0 2025 summary https://pdg.lbl.gov/2025/tables/rpp2025-sum-mesons.pdf .

## Source identity / execution / claim boundaries

Parent EXFOR_CATALOG_2270.csv SHA256 df042ad97e0e6b8f15e600f7b8bf1a77cab21d136fbca4ffd55c2ad64ad4346c. Full prior source ZIP SHA256 5763113fc9b3bb66e057b32a3c53636f7e287413c66d63aa62627cefe93563bf. Byte-preserved parent source dependencies are present in PRIVATE standalone ZIP but excluded from the new Git diff.

Run in full standalone archive root:

    python research/he_dd_pi0_reinjection_20261031/src/generate.py
    cd research/he_dd_pi0_reinjection_20261031
    PYTHONPATH=src python -m unittest discover -s tests -v
    python verify_manifest.py

Parent-independent source semantics and production acceptance remain separate. **Central DAG 28/88, HE physical 14/18, scoped micro 1/1, canonical delta 0**. `kappa=null; R_event=null; heat_rate=null; L4=false; PRODUCTION=HOLD; NO_MERGE=true; NO_FORCE_PUSH=true; AUTO_NEXT_NODE=false`. Blind referee same-author only; native subagents absent; distinct-author R06/C09 NOT_RUN.
