#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python src/generate.py
PYTHONPATH=src python -m unittest discover -s tests -v
python -O -m unittest discover -s tests -q
python verify_manifest.py
