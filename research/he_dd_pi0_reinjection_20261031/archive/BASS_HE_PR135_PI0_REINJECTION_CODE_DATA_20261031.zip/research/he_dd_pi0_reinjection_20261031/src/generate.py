"""Run measured-pi0 injection first generation and original FastD momentum checks."""
from __future__ import annotations
import csv,json,hashlib,sys,os
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
U=Path(__file__).resolve().parents[1];sys.path.insert(0,str(U/'src'))
from pi0_physics import source_rows,selected_angular_rows,pion_source_kinematics,prompt_first_hits,four_nucleon_source,jensen_fastd_table,angular_support_daughter_spectrum,first_hit_daughter_spectra,CUT
plt.rcParams.update({'svg.hashsalt':'BASS_HE_PI0_SOURCE_PHYSICS_20261031','font.size':10})

def write_csv(path,rows):
    if not rows:raise ValueError('no source rows '+str(path))
    path.parent.mkdir(parents=True,exist_ok=True)
    keys=list(rows[0]);assert all(set(r)==set(keys) for r in rows)
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def save(name):
    plt.tight_layout()
    plt.savefig(U/'figures'/f'{name}.png',dpi=170,metadata={'Software':'BASS_HE_source_physics'})
    plt.savefig(U/'figures'/f'{name}.svg',metadata={'Date':'2026-10-31T00:00:00'})
    plt.close()

def main():
    measured_pi=source_rows('M0752019');raw=[dict(E_MeV=r['EN'],sigma_pi_micro_b=r['DATA'],stat_micro_b=r['ERR-S'],sys_micro_b=.07*r['DATA'],EXFOR=r['subentry'],
                        source='Rambo1999 coherent gamma+alpha->alpha+pi0, exact observed') for r in measured_pi]
    write_csv(U/'data'/'PI0_EXFOR_MEASURED_17.csv',raw)
    angular=[r for j in range(4) for r in selected_angular_rows(j)]
    write_csv(U/'data'/'PI0_EXFOR_ANGULAR_101.csv',angular)
    nu=four_nucleon_source();write_csv(U/'data'/'FOUR_NUCLEON_EXFOR_8.csv',nu)
    ene,ang,compar=pion_source_kinematics()
    hit=prompt_first_hits(ene,ang,compar)
    wd=jensen_fastd_table()
    sp=[r for j,E in enumerate([r["E_MeV"] for r in ene]) for r in angular_support_daughter_spectrum(E,j)]
    sp_hit=first_hit_daughter_spectra(sp,hit)
    write_csv(U/'data'/'PION_DAUGHTER_SPECTRUM_SUPPORT_200.csv',sp)
    write_csv(U/'data'/'PION_FIRSTHIT_SPECTRUM_SUPPORT_600.csv',sp_hit)
    for name,rows in [('PION_DAUGHTER_BOUNDS_4',ene),('PION_ANGULAR_SUPPORT_MOMENTS_4',ang),('PION_VS_INCLUSIVE_4',compar),('PION_FIRSTHIT_REINJECTION_12',hit),('FASTD_JETP_JENSEN_2',wd)]:write_csv(U/'data'/f'{name}.csv',rows)
    # source-driven physical charts; show observed systematic and source roles honestly
    x=np.array([r['E_MeV'] for r in compar]);pr=np.array([r['sigma_pi_micro_b'] for r in compar]);ar=np.array([r['sigma_inclusive_interpolated_micro_b'] for r in compar]);
    plt.figure(figsize=(7,4.5));plt.plot(x,ar,'o-',label='MacCormick total absorption (linear interpolation)');plt.plot(x,pr,'s-',label='Rambo coherent pi0');plt.xlabel('Incident photon energy (MeV)');plt.ylabel('Cross section (microbarn)');plt.legend();plt.grid(alpha=.22);save('PI0_VS_INCLUSIVE')
    plt.figure(figsize=(7,4.5));plt.errorbar(x,100*pr/ar,yerr=[100*r['frac_sys_indep_experiments_assumption'] for r in compar],fmt='o-',capsize=4,label='measured coherent pi0 / interpolated inclusive (reported syst only)');plt.xlabel('Incident photon energy (MeV)');plt.ylabel('coherent pi0 / total absorption (%)');plt.grid(alpha=.22);plt.legend(fontsize=8);save('PI0_BRANCHING_SHARE')
    plt.figure(figsize=(7,4.5));l=np.array([r['daughters_gt150_count_lower'] for r in ene]);h=np.array([r['daughters_gt150_count_upper'] for r in ene]);v=np.array([r['mu_daughter_above_count_support_only'] for r in ang]);plt.fill_between(x,l,h,alpha=.22,label='all pion CM angles: exact kinematic bounds');plt.plot(x,v,'o-',label='measured angular support only (7-147 deg)');plt.ylabel('expected daughter gamma count E > 150 MeV / pi0');plt.xlabel('Incident photon energy (MeV)');plt.grid(alpha=.22);plt.legend(fontsize=8);save('PI0_SECONDARY_GAMMA_BOUNDS')
    plt.figure(figsize=(7,4.5));dd=np.array([r['Jensen_lower_mean_Kd_MeV'] for r in wd]);xx=np.arange(2);plt.bar(xx,dd,label='Jensen lower bound of mean deuteron K');plt.xticks(xx,[r['E_gamma_bin_label_MeV'] for r in wd]);plt.ylabel('MeV');plt.xlabel('Gorbunov 1958 bremsstrahlung energy bin (MeV)');plt.grid(axis='y',alpha=.22);plt.legend(fontsize=8);save('JETP1958_FASTD_JENSEN')
    plt.figure(figsize=(7,4.5))
    for E in (206,216,229,241):
        w=[a for a in sp if a['incident_E_MeV']==E]
        plt.plot([(.5*(a['daughter_bin_low_MeV']+a['daughter_bin_high_MeV'])) for a in w],[a['mean_daughter_number_per_pi0']/5 for a in w],label=f'E_in={E} MeV')
    plt.xlabel('Secondary photon energy (MeV)');plt.ylabel('Expected daughters / (pion MeV)');plt.grid(alpha=.22);plt.legend(fontsize=8);save('PI0_PROMPT_DAUGHTER_SPECTRA')
    summary={'unit':'HE4_COHERENT_PI0_PHOTON_REINJECTION_AND_JETP_FASTD_JENSEN_20261031',
       'parent_pr':134,'parent_head':'241d8e90607ff7ff28ca643a8e39ae189bde3d19',
       'central_dag':'28/88','he_physical_dag':'14/18','canonical_physical_delta':0,'measured_source_rows':len(raw)+len(angular)+len(nu)+2,
       'source_rows_not_all_independent':True,'new_derived_physics_rows':len(ene)+len(ang)+len(compar)+len(hit)+len(wd)+len(sp)+len(sp_hit),
       'source_angle_conditional_photon_spectrum_rows':len(sp),
       'source_angle_conditional_first_hit_spectrum_rows':len(sp_hit),
       'source_pi0_total_rows':len(raw),'source_pi0_angular_rows':len(angular),'source_four_nucleon_rows':len(nu),
       'gamma_kinematic_envelope_rows':len(ene),'pi0_rate_rows':len(hit),'jetp_fastd_jensen_rows':len(wd),
       'pi0_share':compar,'pi0_envelope':ene,'pi0_first_hit_at_z10000':[r for r in hit if r['z']==1e4],
       'Jensen_fastd':wd,
       'scope':'FIRST_GENERATION gamma pi0 source recon only; no full cascades or heat',
       'production':'HOLD','R_event':None,'heat_rate':None,'kappa':None,'L4':False,'no_merge':True,'no_force_push':True,'auto_next_node':False}
    (U/'data'/'SCIENTIFIC_SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k in ('source_pi0_total_rows','source_pi0_angular_rows','source_four_nucleon_rows','new_derived_physics_rows','measured_source_rows','central_dag','he_physical_dag')},indent=2));print('PI0 fractions',[(z['E_MeV'],z['exclusive_pi0_over_inclusive']) for z in compar]);print('Pion daughter envelope',[(z['E_MeV'],z['daughters_gt150_count_lower'],z['daughters_gt150_count_upper']) for z in ene]);print('FastD',[(z['E_gamma_bin_label_MeV'],z['Jensen_lower_mean_Kd_MeV'],z['inferred_lower_mean_E_gamma_MeV']) for z in wd]);

if __name__=='__main__':main()
