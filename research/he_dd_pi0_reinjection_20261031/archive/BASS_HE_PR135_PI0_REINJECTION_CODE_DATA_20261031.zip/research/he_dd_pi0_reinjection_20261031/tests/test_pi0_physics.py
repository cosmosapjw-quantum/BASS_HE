import unittest, sys, math, hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from pi0_physics import (source_rows,selected_angular_rows,pion_cm,pion_lab,daughter_above,pion_source_kinematics,
                        interpolated_absorption,prompt_first_hits,four_nucleon_source,jensen_fastd_table,angular_support_daughter_spectrum,first_hit_daughter_spectra,M_PI0,M_ALPHA,B_2G,CUT,SRC)

class TestMeasuredPionFirstGeneration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ph,cls.ang,cls.comp=pion_source_kinematics()
    def test_parent_source_identity(self):
        self.assertEqual(hashlib.sha256(SRC.read_bytes()).hexdigest(),'df042ad97e0e6b8f15e600f7b8bf1a77cab21d136fbca4ffd55c2ad64ad4346c')
    def test_measured_subentry_exact_roles(self):
        p=source_rows('M0752019');self.assertEqual(len(p),17)
        self.assertTrue(all('PI0' in x['reaction'] and 'PAR,SIG' in x['reaction'] for x in p))
        self.assertEqual(len(four_nucleon_source()),8)
    def test_pi0_source_four_scoped_energies(self):
        self.assertEqual([x['E_MeV'] for x in self.ph],[206,216,229,241])
        self.assertEqual([x['sigma_pi_micro_b'] for x in self.comp],[150,174.5,212.6,260.3])
    def test_inclusive_is_typed_and_interpolated(self):
        a=interpolated_absorption(216);self.assertEqual(a['sigma_micro_b'],879.)
        self.assertTrue(a['measured_E']);self.assertAlmostEqual(interpolated_absorption(206)['sigma_micro_b'],748.1666666666666,places=9)
        with self.assertRaises(ValueError):interpolated_absorption(100)
    def test_nuclear_recoil_threshold(self):
        self.assertAlmostEqual(pion_cm(206)['threshold_MeV'],M_PI0+M_PI0*M_PI0/(2*M_ALPHA),places=12)
        with self.assertRaises(ValueError):pion_cm(136)
    def test_lab_energy_momentum_conservation(self):
        for E in (206,216,229,241):
            for mu in np.linspace(-1,1,25):
                v=pion_lab(E,float(mu));self.assertAlmostEqual(E,v['recoil_alpha_K_MeV']+v['E_pi_MeV'],places=11)
                self.assertAlmostEqual(v['E_pi_MeV']**2-v['p_pi_c_MeV']**2,M_PI0*M_PI0,delta=3e-9)
                self.assertAlmostEqual(v['E_gamma_min_MeV']+v['E_gamma_max_MeV'],v['E_pi_MeV'],places=10)
    def test_two_gamma_reinjection_energy_and_count(self):
        for E in (206,216,229,241):
            for mu in np.linspace(-1,1,11):
                d=daughter_above(E,float(mu));self.assertTrue(0<=d['count_above_per_pi0']<=2*B_2G)
                self.assertAlmostEqual(d['E_below_per_pi0_MeV']+d['E_above_per_pi0_MeV'], B_2G*d['E_pi_MeV'],places=10)
    def test_kinematic_bounds_cover_arbitrary_angles(self):
        for E,env in zip((206,216,229,241),self.ph):
            for mu in np.linspace(-1,1,200):
                x=daughter_above(E,float(mu))['count_above_per_pi0']
                self.assertLessEqual(env['daughters_gt150_count_lower']-x,1e-11)
                self.assertLessEqual(x-env['daughters_gt150_count_upper'],1e-11)
    def test_angular_source_support_not_full_sphere(self):
        for j,a in enumerate(self.ang):
            src=selected_angular_rows(j);self.assertGreaterEqual(len(src),25)
            self.assertGreater(a['theta_min_deg'],0);self.assertLess(a['theta_max_deg'],180)
            self.assertGreater(a['sigma_partial_micro_b'],0)
            self.assertLess(abs(a['partial_vs_total_ratio']-1),.07)  # within published source systematic; not forced equality
    def test_angular_shape_proxy_inside_full_kinematic_bounds(self):
        for a,p in zip(self.ang,self.ph):
            v=a['mu_daughter_above_count_support_only']
            self.assertLessEqual(p['daughters_gt150_count_lower']-v,1e-12)
            self.assertLessEqual(v-p['daughters_gt150_count_upper'],1e-12)
    def test_source_pi0_fraction_216(self):
        f=self.comp[1]['exclusive_pi0_over_inclusive'];self.assertAlmostEqual(f,174.5/879.,places=14)
        self.assertGreater(f,0);self.assertLess(f,1)
    def test_reported_separate_stat_and_sys(self):
        self.assertEqual(self.comp[1]['pi_stat_micro_b'],.8)
        self.assertAlmostEqual(self.comp[1]['pi_sys_micro_b'],.07*174.5)
    def test_full_source_angular_bins_cover_measured_total(self):
        self.assertEqual(sum(len(selected_angular_rows(j)) for j in range(4)),101)
    def test_firsthit_probabilities_and_secondary_bounds(self):
        rows=prompt_first_hits(self.ph,self.ang,self.comp)
        self.assertEqual(len(rows),12)
        for r in rows:
            self.assertGreaterEqual(r['P_first_pi0'],0)
            self.assertLessEqual(r['P_first_pi0'],1)
            self.assertLessEqual(r['N_high_photons_per_injected_gamma_lower']-r['N_high_photons_per_injected_gamma_angular_support_proxy'],1e-12)
            self.assertLessEqual(r['N_high_photons_per_injected_gamma_angular_support_proxy']-r['N_high_photons_per_injected_gamma_upper'],1e-12)
            self.assertLess(r['H_times_tau_pi0'],1e-18)
    def test_pion_local_prob_216_z10000(self):
        r=next(x for x in prompt_first_hits(self.ph,self.ang,self.comp) if x['E_MeV']==216 and x['z']==1e4)
        self.assertAlmostEqual(r['P_first_pi0'],.0009480750669128686,delta=2e-10)
    def test_2p2n_zero_not_an_exact_absence(self):
        p=four_nucleon_source();self.assertEqual(p[0]['sigma_2p2n_micro_b'],0)
        self.assertGreater(p[0]['stat_micro_b'],0)
        self.assertTrue(all(x['deuteron_direct_birth_count']==0 for x in p))
    def test_JETP_jensen_mean_not_point_momentum(self):
        arr=jensen_fastd_table()
        self.assertEqual(len(arr),2)
        self.assertAlmostEqual(arr[1]['Jensen_lower_mean_Kd_MeV'],9.598958075679093,places=9)
        self.assertAlmostEqual(arr[1]['inferred_lower_mean_E_gamma_MeV'],94.80944652720098,places=9)
        self.assertTrue(all(x['mean_K_not_equal_K_of_mean_p'] for x in arr))
    def test_fastD_lower_bound_below_total_available(self):
        for x in jensen_fastd_table():self.assertLess(x['inferred_lower_mean_E_gamma_MeV'],x['E_gamma_high_MeV'])
    def test_pion_decay_spectral_number_conservation(self):
        for j,E in enumerate((206,216,229,241)):
            rows=angular_support_daughter_spectrum(E,j)
            self.assertEqual(len(rows),50)
            self.assertAlmostEqual(sum(r['mean_daughter_number_per_pi0'] for r in rows),2*B_2G,places=10)
    def test_pion_decay_above_cut_spectrum_agreement(self):
        for j,E in enumerate((206,216,229,241)):
            rows=angular_support_daughter_spectrum(E,j)
            v=sum(r['mean_daughter_number_per_pi0'] for r in rows if r['daughter_bin_low_MeV']>=150)
            self.assertAlmostEqual(v,self.ang[j]['mu_daughter_above_count_support_only'],places=10)
    def test_pion_decay_energy_integrity(self):
        for j,E in enumerate((206,216,229,241)):
            rows=angular_support_daughter_spectrum(E,j)
            self.assertAlmostEqual(sum(r['gamma_energy_MeV_per_pi0'] for r in rows),B_2G*self.ang[j]['mu_pion_energy_support_MeV'],places=9)
    def test_pion_source_firsthit_spectral_integrity(self):
        sp=[r for j,E in enumerate((206,216,229,241)) for r in angular_support_daughter_spectrum(E,j)]
        hits=prompt_first_hits(self.ph,self.ang,self.comp)
        converted=first_hit_daughter_spectra(sp,hits)
        self.assertEqual(len(converted),600)
        self.assertAlmostEqual(sum(r['expected_daughter_number_per_injected_gamma'] for r in converted if r['incident_E_MeV']==216 and r['z']==1e4),
                               2*B_2G*next(r for r in hits if r['E_MeV']==216 and r['z']==1e4)['P_first_pi0'],places=12)
    def test_no_D_fast_in_coherent_pi0_channel(self):
        self.assertTrue(all(r['alpha_retained_on_pi0_event'] for r in prompt_first_hits(self.ph,self.ang,self.comp)))

if __name__=='__main__':unittest.main()
