from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[2]; base=r/'research/he_dd_pi0_reinjection_20261031'
manifest=json.loads((base/'MANIFEST_SHA256.json').read_text())
missing=[];bad=[]
for rel,expected in manifest.items():
    p=r/rel
    if not p.is_file():missing.append(rel)
    elif hashlib.sha256(p.read_bytes()).hexdigest()!=expected:bad.append(rel)
print(f'MANIFEST: {len(manifest)-len(missing)-len(bad)}/{len(manifest)} SHA256 exact; missing={missing},bad={bad}')
assert not missing and not bad
