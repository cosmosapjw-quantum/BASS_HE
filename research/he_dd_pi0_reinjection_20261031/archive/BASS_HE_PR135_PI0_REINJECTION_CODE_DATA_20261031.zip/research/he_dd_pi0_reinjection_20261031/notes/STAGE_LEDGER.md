# R/C stages, bounded science PR135

| Stage | Actual artifact | Central | HE | Local | Backup |
|---|---|---|---|---|---|
| R01 | stages/R01.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| R02 | stages/R02.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| R03 | stages/R03.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| R04 | stages/R04.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| R05 | stages/R05.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| R06 | stages/R06.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| R07 | stages/R07.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| R08 | stages/R08.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| R09 | stages/R09.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| R10 | stages/R10.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C01 | stages/C01.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C02 | stages/C02.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C03 | stages/C03.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C04 | stages/C04.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C05 | stages/C05.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C06 | stages/C06.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C07 | stages/C07.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C08 | stages/C08.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C09 | stages/C09.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
| C10 | stages/C10.md (actual source/derivation/code or verification note) | 28/88 | 14/18 | 1/1 scoped | bundled ZIP + eventual Library/Drive/Git receipt |
